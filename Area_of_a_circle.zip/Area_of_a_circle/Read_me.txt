-GSE301 Java Programming Class
-First Snippet App created
-Area of a Circle v1.0

Kindly check the final output of the code in dist folder